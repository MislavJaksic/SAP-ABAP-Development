sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History"
], function(BaseController, MessageBox, Utilities, History) {
	"use strict";

	return BaseController.extend("generated.app.controller.TranslateUi", {

		/*New Stuff*/
		translateButtonPressed: function() {
			var self = this;
			var aLangName = ["German", "Spanish (Spain)", "French (France)", "Italian", "Portuguese (Brazil)", "Croatian",
				"Slovenian"
			];
			var aLangCode = ["de", "es", "fr", "it", "pt", "hr", "sl"];
			var oldText = this.getView().byId("OldText").getValue();
			var newLang = this.getView().byId("NewLang").getSelectedItem();
			if (newLang !== null) {
				//var oldLangCode = aLangCode[aLangName.indexOf(oldLang.mProperties.text)];     
				var newLangCode = aLangCode[aLangName.indexOf(newLang.mProperties.text)];
				var data = "{\r\n  \"sourceLanguage\":en,\r\n  \"targetLanguages\": [\r\n " + newLangCode +
					"   \r\n  ],\r\n  \"units\": [\r\n    {\r\n      \"value\":\"" + oldText + "\"\r\n    }\r\n  ]\r\n}";
				var xhr = new XMLHttpRequest();
				xhr.withCredentials = true;
				xhr.addEventListener("readystatechange", function() {
					if (this.readyState === this.DONE) {
						sap.m.MessageToast.show("Translated!");
						self.getView().byId("NewText").setValue(JSON.parse(this.responseText).units[0].translations[0].value);
					}
				});
				//setting request method
				xhr.open("POST", "https://sandbox.api.sap.com/translationhub/api/v1/translate");

				//adding request headers
				xhr.setRequestHeader("Content-Type", "string");
				xhr.setRequestHeader("Accept", "application/json; charset=utf-8");
				xhr.setRequestHeader("APIKey", "3ym6rj9b2v2Pg2Bodvjesy5hm7ZAeH2K");

				//sending request
				xhr.send(data);
			} else {
				var dialog = new sap.m.Dialog({
					title: 'Missing Language',
					type: 'Message',
					state: 'Error',
					content: new sap.m.Text({
						text: "Please select a language."
					}),
					beginButton: new sap.m.Button({
						text: 'OK',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			}
		},
		/*End of New Stuff*/
		handleRouteMatched: function(oEvent) {

			var oParams = {};

			if (oEvent.mParameters.data.context) {
				this.sContext = oEvent.mParameters.data.context;
				var oPath;
				if (this.sContext) {
					oPath = {
						path: "/" + this.sContext,
						parameters: oParams
					};
					this.getView().bindObject(oPath);
				}
			}

		},
		onInit: function() {

			this.mBindingOptions = {};
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("TranslateUi").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));

		}
	});
}, /* bExport= */ true);